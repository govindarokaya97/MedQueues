from django.urls import path 
from . import views

urlpatterns = [
    path('', views.MedicineListView.as_view(), name='medicine_list'),
    path('add/', views.MedicineCreateView.as_view(), name='medicine_add'),
    path('<int:id>/', views.MedicineDetailView.as_view(), name='medicine_detail'),
    path('<int:id>/edit/', views.MedicineUpdateView.as_view(), name='medicine_edit'),
    path('<int:id>/delete/', views.MedicineDeleteView.as_view(), name='medicine_delete'),
]
