from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import (ListView, DetailView, CreateView, UpdateView, DeleteView)
from .models import Medicine, MedicineCategory
from .forms import MedicineForm
from django.db.models import Q

# Create your views here.

class MedicineListView(ListView):
    model = Medicine
    template_name = "pharmacy/medicine_list.html"
    context_object_name = "medicines"
    paginate_by = 10
    
    def get_queryset(self):
        queryset = Medicine.objects.select_related("category")
        
        search = self.request.GET.get("search")
        
        if search:
            queryset = queryset.filter(
                Q(name__icontains=search) |
                Q(generic_name__icontains=search) |
                Q(batch_number__icontains=search) |
                Q(manufacturer__icontains=search)
            )
        
        category = self.request.GET.get("category")
        if category:
            queryset = queryset.filter(category_id=category)
            
        return queryset.order_by("name")
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        selected_category = self.request.GET.get("category", "")
        context["category_options"] = [
            {"id": c.id, "name": c.name, "is_selected": str(c.id) == selected_category}
            for c in MedicineCategory.objects.all()
        ]
        return context
    
    
    
class MedicineDetailView(DetailView):
    model = Medicine
    pk_url_kwarg = "id"
    template_name = "pharmacy/medicine_detail.html"
    
    
    
class MedicineCreateView(CreateView):
    model = Medicine
    form_class = MedicineForm
    template_name = "pharmacy/medicine_form.html"
    success_url = reverse_lazy("medicine_list")
    
    
class MedicineUpdateView(UpdateView):
    model = Medicine
    pk_url_kwarg = "id"
    form_class = MedicineForm
    template_name = "pharmacy/medicine_form.html"
    success_url = reverse_lazy("medicine_list")
    
    
class MedicineDeleteView(DeleteView):
    model = Medicine
    pk_url_kwarg = "id"
    template_name = "pharmacy/medicine_confirm_delete.html"
    success_url = reverse_lazy("medicine_list")